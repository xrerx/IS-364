
window.addEventListener('scroll', function() {
    let header = document.querySelector('header');
    let hero = document.querySelector('.hero');
    let heroHeight = hero.offsetHeight;
  
    if (window.pageYOffset > heroHeight) {
      header.classList.add('sticky');
    } else {
      header.classList.remove('sticky');
    }
  });
  




